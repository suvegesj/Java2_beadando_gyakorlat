package com.example.nb1;

import org.springframework.data.repository.CrudRepository;
public interface posztRepo extends CrudRepository<poszt, Integer>{
}


