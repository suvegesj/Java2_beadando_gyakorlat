package com.example.nb1;

import org.springframework.data.repository.CrudRepository;
public interface klubRepo extends CrudRepository<klub, Integer>{
}


